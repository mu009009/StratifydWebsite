// Time for Transition Animation setting
var ShorDurationTime = 200;
var MiddleDurationTime = 500;
var LongDurationTime = 1000;