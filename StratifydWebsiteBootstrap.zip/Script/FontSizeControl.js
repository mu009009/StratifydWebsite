var windowWidth = window.innerWidth;
var StanderedSize = windowWidth/120;
var ExtraSize = 2 * StanderedSize;

console.log(StanderedSize);

//d3.selectAll('.ButtonText')
//.style("font-size",StanderedSize+"px");
//
//d3.selectAll('.IntroTitle')
//.style("font-size",ExtraSize+"px");