window.onresize = function()
{
//	VerticalCenterTry();
//	VerticalCenterBubble();
//	
//	BubbleButton = document.getElementById("CircleBubble1").getBoundingClientRect().width;
//	BubbleBoxWidth = document.getElementById("BubbleIconBox1").getBoundingClientRect().width;
//	
//	BottomIconsWidth = document.getElementById("ExecutiveIcon").getBoundingClientRect().width;
//	BottomMargineLeftStr = d3.select("#ExecutiveIcon").style("margin-left");
//	BottomMargineLeftValue = parseFloat(ValuewithPxStrtoNumValue(BottomMargineLeftStr));
	window.location.reload();
}